# Cara membangun APK AquaMonitor hanya dari HP Android

Proyek ini sudah memiliki workflow GitHub Actions untuk membangun APK di cloud.

## Langkah-langkah
1. Unduh dan ekstrak `AquaMonitorNative_AndroidStudio_Project.zip` di HP. Jika aplikasi file manager tidak dapat mengekstrak, gunakan aplikasi pengelola ZIP tepercaya.
2. Buat akun atau masuk ke GitHub melalui browser: https://github.com
3. Buat repository baru. Untuk build cloud tanpa biaya Actions pada runner standar, repository dapat dibuat **Public**. Perlu diingat, source code pada repository public dapat dilihat orang lain. Jangan mengunggah kata sandi, token, atau data pribadi.
4. Unggah seluruh isi folder proyek ke repository, termasuk folder tersembunyi `.github/workflows/build-apk.yml`. Pastikan file `settings.gradle`, `build.gradle`, `gradle.properties`, dan folder `app` berada di root repository.
5. Buka tab **Actions** pada repository. Jika diminta, aktifkan GitHub Actions.
6. Pilih workflow **Build AquaMonitor APK**, lalu tekan **Run workflow**. Jika Anda baru mengunggah source ke branch `main`, workflow juga berjalan otomatis saat push.
7. Tunggu workflow selesai dengan tanda centang hijau. Buka run yang terbaru, gulir ke bagian **Artifacts**, lalu unduh `AquaMonitor-debug-APK`.
8. Ekstrak ZIP artifact yang diunduh. Di dalamnya ada `app-debug.apk`.
9. Buka APK di HP dan ikuti instruksi Android untuk mengizinkan pemasangan aplikasi dari sumber tersebut.

## Catatan
- Ini APK debug untuk uji coba pribadi, belum APK release bertanda tangan untuk distribusi publik.
- GitHub Actions standar umumnya tersedia gratis dalam batas paket/jenis repository yang berlaku; cek halaman billing GitHub sebelum mengaktifkan penggunaan berbayar.
- Jangan pernah membagikan password atau token GitHub kepada siapa pun.
- Koneksi ESP32 harus berada di Wi-Fi yang sama dengan HP dan menyediakan `GET http://IP-ESP32/api/sensors`.
