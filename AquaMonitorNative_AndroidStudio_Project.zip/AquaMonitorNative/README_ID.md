# AquaMonitor Native Android (source project)

Ini adalah proyek sumber Android native (Java), bukan APK hasil kompilasi. Fitur yang disediakan:
- Dashboard native Android.
- Mode demo.
- Polling ESP32 tiap 3 detik pada saat aplikasi terbuka.
- Grafik suhu dan daftar ringkas riwayat sesi.
- Pengaturan batas suhu dan notifikasi Android ketika batas dilampaui.
- Endpoint JSON yang fleksibel untuk sensor yang belum ditambahkan.

## Cara membuka dan membangun APK
1. Instal Android Studio pada komputer.
2. Ekstrak ZIP proyek ini.
3. Android Studio > Open > pilih folder `AquaMonitorNative`.
4. Tunggu Gradle sync dan izinkan Android Studio mengunduh Android Gradle Plugin serta Android SDK yang diperlukan.
5. Pilih Build > Build APK(s). APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.
6. Salin APK ke HP Android dan instal. Android mungkin meminta izin instalasi dari sumber tersebut.

## Menghubungkan ESP32
- HP dan ESP32 harus berada pada jaringan Wi-Fi yang sama.
- Masukkan alamat IP ESP32 di layar aplikasi dan tekan Hubungkan ESP32.
- Aplikasi meminta `GET http://IP-ESP32/api/sensors` setiap 3 detik selama aplikasi terbuka.
- Contoh respons:
```json
{
  "temp_c": 27.4,
  "tds_ppm": 245,
  "ph": 7.1,
  "salinity_ppt": null,
  "iron_mg_l": null
}
```
- Jika parameter belum tersedia, kirim `null` atau hilangkan field-nya.

## Batasan prototipe
- Notifikasi dan polling berjalan saat aplikasi terbuka; belum memantau 24/7 saat aplikasi ditutup.
- Riwayat saat ini hanya disimpan di memori sesi dan dibatasi untuk tampilan, belum ke database permanen.
- Koneksi memakai HTTP lokal untuk prototipe. Jangan meneruskan pola ini ke server internet tanpa keamanan yang memadai.
- Sensor pH/TDS/salinitas/Fe harus dikalibrasi dan dipilih sesuai parameter. TDS tidak dapat mengukur besi spesifik.
- Proyek ini belum dikompilasi menjadi APK di lingkungan ini karena Android SDK/Gradle build tool tidak tersedia di sini.
