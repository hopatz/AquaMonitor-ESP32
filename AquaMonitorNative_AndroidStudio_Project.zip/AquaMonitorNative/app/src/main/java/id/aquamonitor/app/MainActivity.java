package id.aquamonitor.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.Manifest;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private EditText ipInput, minInput, maxInput;
    private TextView status, temp, tds, ph, salinity, iron, updated, alert;
    private LinearLayout historyRows;
    private ChartView chart;
    private final ArrayList<Float> temperatureHistory = new ArrayList<>();
    private boolean demo = true;
    private boolean fetching = false;
    private float latestTemp = 27.4f;
    private int demoStep = 0;

    private final Runnable poller = new Runnable() {
        @Override public void run() {
            if (demo) updateDemo();
            else fetchSensors();
            handler.postDelayed(this, 3000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("aqua", MODE_PRIVATE);
        createNotificationChannel();
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
        buildUi();
        handler.post(poller);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(2), dp(3), dp(2), dp(3)); return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = vertical(); page.setPadding(dp(16), dp(20), dp(16), dp(28));
        page.setBackgroundColor(Color.rgb(242,248,250)); scroll.addView(page);
        TextView title = text("AquaMonitor", 27, Color.WHITE); title.setTypeface(null, 1);
        TextView subtitle = text("Pemantauan kualitas air • ESP32", 13, Color.WHITE);
        LinearLayout hero = vertical(); hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackgroundColor(Color.rgb(7,91,116)); hero.addView(title); hero.addView(subtitle);
        status = text("● Mode demo", 13, Color.rgb(16,130,96)); status.setPadding(dp(0),dp(12),0,dp(12));
        page.addView(hero); page.addView(status);

        addHeading(page, "Koneksi perangkat");
        ipInput = new EditText(this); ipInput.setSingleLine(true); ipInput.setText(prefs.getString("ip","192.168.1.50"));
        ipInput.setHint("Alamat IP ESP32, contoh 192.168.1.50");
        page.addView(ipInput);
        LinearLayout actions = horizontal();
        Button connect = new Button(this); connect.setText("Hubungkan ESP32");
        Button demoBtn = new Button(this); demoBtn.setText("Mode demo");
        actions.addView(connect, new LinearLayout.LayoutParams(0, -2, 1)); actions.addView(demoBtn, new LinearLayout.LayoutParams(0,-2,1));
        page.addView(actions);
        connect.setOnClickListener(v -> {
            String ip = ipInput.getText().toString().trim().replace("http://","").replace("/","");
            if(ip.isEmpty()){ toast("Masukkan alamat IP ESP32"); return; }
            prefs.edit().putString("ip",ip).apply(); demo=false;
            status.setText("● Menghubungkan ke "+ip); status.setTextColor(Color.rgb(11,114,133));
            fetchSensors();
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(ipInput.getWindowToken(),0);
        });
        demoBtn.setOnClickListener(v -> { demo=true; updateDemo(); });

        addHeading(page, "Dashboard sensor");
        LinearLayout row1=horizontal();
        row1.addView(metric("SUHU AIR","—","DS18B20"), new LinearLayout.LayoutParams(0,-2,1));
        row1.addView(metric("TDS","—","ppm"), new LinearLayout.LayoutParams(0,-2,1));
        page.addView(row1);
        temp=(TextView)((LinearLayout)row1.getChildAt(0)).getChildAt(1);
        tds=(TextView)((LinearLayout)row1.getChildAt(1)).getChildAt(1);
        LinearLayout row2=horizontal();
        row2.addView(metric("pH","—","Keasaman"), new LinearLayout.LayoutParams(0,-2,1));
        row2.addView(metric("SALINITAS","—","ppt"), new LinearLayout.LayoutParams(0,-2,1));
        page.addView(row2);
        ph=(TextView)((LinearLayout)row2.getChildAt(0)).getChildAt(1);
        salinity=(TextView)((LinearLayout)row2.getChildAt(1)).getChildAt(1);
        LinearLayout row3=horizontal();
        row3.addView(metric("KADAR BESI (Fe)","Belum tersedia","Sensor khusus"), new LinearLayout.LayoutParams(-1,-2,1));
        page.addView(row3); iron=(TextView)((LinearLayout)row3.getChildAt(0)).getChildAt(1);

        addHeading(page, "Grafik riwayat suhu");
        chart = new ChartView(this); page.addView(chart, new LinearLayout.LayoutParams(-1, dp(190)));
        updated=text("Belum ada pembacaan.", 11, Color.DKGRAY); page.addView(updated);

        addHeading(page, "Peringatan suhu");
        TextView help=text("Notifikasi muncul saat aplikasi berjalan dan suhu di luar rentang berikut.",12,Color.DKGRAY); page.addView(help);
        LinearLayout limits=horizontal();
        minInput=new EditText(this); minInput.setInputType(8194); minInput.setSingleLine(true); minInput.setHint("Min °C"); minInput.setText(prefs.getString("min","10"));
        maxInput=new EditText(this); maxInput.setInputType(8194); maxInput.setSingleLine(true); maxInput.setHint("Max °C"); maxInput.setText(prefs.getString("max","35"));
        Button save=new Button(this); save.setText("Simpan");
        limits.addView(minInput,new LinearLayout.LayoutParams(0,-2,1)); limits.addView(maxInput,new LinearLayout.LayoutParams(0,-2,1)); limits.addView(save);
        page.addView(limits);
        alert=text("Suhu dalam rentang pengaturan.",12,Color.rgb(16,130,96)); page.addView(alert);
        save.setOnClickListener(v -> {
            prefs.edit().putString("min",minInput.getText().toString()).putString("max",maxInput.getText().toString()).apply();
            updateAlert(latestTemp,true); toast("Batas suhu disimpan");
        });
        addHeading(page,"Riwayat pembacaan");
        historyRows=vertical(); page.addView(historyRows);
        TextView note=text("Catatan: angka demo hanya contoh. TDS tidak dapat mengukur kadar besi secara spesifik. Sensor pH, TDS, salinitas, dan Fe memerlukan perangkat serta kalibrasi yang sesuai.",11,Color.rgb(83,108,118));
        note.setPadding(0,dp(18),0,0); page.addView(note);
        setContentView(scroll);
    }

    private void addHeading(LinearLayout page,String s) {
        TextView h=text(s,18,Color.rgb(18,48,58)); h.setTypeface(null,1);
        h.setPadding(0,dp(18),0,dp(8)); page.addView(h);
    }
    private LinearLayout metric(String label,String value,String unit) {
        LinearLayout box=vertical(); box.setPadding(dp(12),dp(12),dp(10),dp(12));
        box.setBackgroundColor(Color.WHITE);
        TextView a=text(label,10,Color.rgb(86,121,132)); a.setTypeface(null,1);
        TextView b=text(value,23,Color.rgb(11,114,133)); b.setTypeface(null,1);
        TextView c=text(unit,10,Color.GRAY);
        box.addView(a);box.addView(b);box.addView(c);
        LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)box.getLayoutParams();
        return box;
    }
    private void updateDemo() {
        demoStep++;
        latestTemp = 27.4f + (float)Math.sin(demoStep/3.0)*0.6f;
        JSONObject d = new JSONObject();
        try { d.put("temp_c",latestTemp); d.put("tds_ppm",245+(demoStep%9)-4); d.put("ph",7.1+(demoStep%5-2)*0.02); } catch(Exception ignored){}
        showData(d,true);
        status.setText("● Mode demo — data contoh"); status.setTextColor(Color.rgb(16,130,96));
    }
    private void fetchSensors() {
        if(fetching) return;
        String ip=ipInput.getText().toString().trim().replace("http://","").replace("/","");
        if(ip.isEmpty()) return;
        fetching=true;
        executor.execute(() -> {
            HttpURLConnection conn=null;
            try {
                URL url=new URL("http://"+ip+"/api/sensors");
                conn=(HttpURLConnection)url.openConnection(); conn.setConnectTimeout(2500); conn.setReadTimeout(2500); conn.setRequestMethod("GET");
                if(conn.getResponseCode()!=200) throw new Exception("HTTP "+conn.getResponseCode());
                BufferedReader br=new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb=new StringBuilder(); String line;
                while((line=br.readLine())!=null)sb.append(line); br.close();
                JSONObject d=new JSONObject(sb.toString());
                runOnUiThread(() -> { demo=false; showData(d,false); status.setText("● ESP32 terhubung"); status.setTextColor(Color.rgb(16,130,96)); });
            } catch(Exception e) {
                runOnUiThread(() -> { status.setText("● Gagal terhubung — periksa IP/Wi-Fi/API"); status.setTextColor(Color.rgb(185,55,55)); });
            } finally { if(conn!=null)conn.disconnect(); fetching=false; }
        });
    }
    private void showData(JSONObject d,boolean isDemo) {
        if(d.has("temp_c")&&!d.isNull("temp_c")) {
            latestTemp=(float)d.optDouble("temp_c",latestTemp);
            temp.setText(String.format(Locale.US,"%.1f °C",latestTemp));
            temperatureHistory.add(latestTemp); if(temperatureHistory.size()>30)temperatureHistory.remove(0);
            chart.setValues(temperatureHistory);
            updateAlert(latestTemp,false);
            addHistory(String.format(Locale.US,"Suhu %.1f °C • TDS %s ppm • pH %s",latestTemp,d.has("tds_ppm")?d.optString("tds_ppm"):"—",d.has("ph")?d.optString("ph"):"—"));
        }
        tds.setText(d.isNull("tds_ppm")||!d.has("tds_ppm")?"—":d.optString("tds_ppm")+" ppm");
        ph.setText(d.isNull("ph")||!d.has("ph")?"—":String.format(Locale.US,"%.2f",d.optDouble("ph")));
        salinity.setText(d.isNull("salinity_ppt")||!d.has("salinity_ppt")?"Belum tersedia":d.optString("salinity_ppt")+" ppt");
        iron.setText(d.isNull("iron_mg_l")||!d.has("iron_mg_l")?"Belum tersedia":d.optString("iron_mg_l")+" mg/L");
        updated.setText("Pembaruan terakhir: "+new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())+(isDemo?" (demo)":""));
    }
    private void addHistory(String s) {
        if(historyRows==null)return;
        TextView item=text("• "+new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())+"  "+s,11,Color.rgb(65,91,101));
        historyRows.addView(item,0);
        while(historyRows.getChildCount()>12)historyRows.removeViewAt(historyRows.getChildCount()-1);
    }
    private void updateAlert(float t,boolean force) {
        float min=parse(minInput==null?"10":minInput.getText().toString(),10);
        float max=parse(maxInput==null?"35":maxInput.getText().toString(),35);
        if(t<min||t>max) {
            alert.setText("PERINGATAN: suhu "+String.format(Locale.US,"%.1f",t)+" °C di luar batas "+min+"–"+max+" °C");
            alert.setTextColor(Color.rgb(185,55,55));
            if(force || !prefs.getBoolean("alertSent",false)) sendNotification(t,min,max);
            prefs.edit().putBoolean("alertSent",true).apply();
        } else {
            alert.setText("Suhu dalam rentang pengaturan."); alert.setTextColor(Color.rgb(16,130,96));
            prefs.edit().putBoolean("alertSent",false).apply();
        }
    }
    private float parse(String s,float d){try{return Float.parseFloat(s);}catch(Exception e){return d;}}
    private void sendNotification(float t,float min,float max) {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        Notification.Builder b = Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"aqua_alert"):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("AquaMonitor: peringatan suhu")
          .setContentText(String.format(Locale.US,"Suhu %.1f °C di luar batas %.1f–%.1f °C",t,min,max))
          .setAutoCancel(true);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1001,b.build());
    }
    private void createNotificationChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel("aqua_alert","Peringatan AquaMonitor",NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("Peringatan batas suhu air");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){handler.removeCallbacks(poller);executor.shutdownNow();super.onDestroy();}

    private class ChartView extends View {
        private final Paint p=new Paint(3); private ArrayList<Float> values=new ArrayList<>();
        ChartView(Context c){super(c);setBackgroundColor(Color.WHITE);}
        void setValues(ArrayList<Float> v){values=new ArrayList<>(v);invalidate();}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);float w=getWidth(),h=getHeight(),left=dp(35),right=dp(10),top=dp(15),bottom=dp(24);
            p.setColor(Color.rgb(226,237,240));p.setStrokeWidth(dp(1));
            for(int i=0;i<4;i++){float y=top+(h-top-bottom)*i/3f;canvas.drawLine(left,y,w-right,y,p);}
            if(values.size()<2)return;
            float min=Float.MAX_VALUE,max=-Float.MAX_VALUE;for(float v:values){min=Math.min(min,v);max=Math.max(max,v);}
            min-=0.5f;max+=0.5f;if(max-min<0.1f)max=min+1;
            p.setColor(Color.rgb(11,154,168));p.setStrokeWidth(dp(2.5f));p.setStyle(Paint.Style.STROKE);
            Path path=new Path();
            for(int i=0;i<values.size();i++){float x=left+i*(w-left-right)/(values.size()-1);float y=top+(max-values.get(i))*(h-top-bottom)/(max-min);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}
            canvas.drawPath(path,p);p.setStyle(Paint.Style.FILL);
        }
    }
}
